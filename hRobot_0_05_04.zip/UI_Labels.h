#include <cstddef>
#include <cstdint>
#include "hFramework.h"
#include "hCloudClient.h"

#ifndef __UI_Labels__
#define __UI_Labels__

void printOnLabels();

#endif //__UI_Labels__