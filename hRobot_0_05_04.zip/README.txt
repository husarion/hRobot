UI v.0.01.3

* Wyb�r label="info" do wy�wietlenia (int "pos_label")
