UI v.0.01.4

	label show name of value depend on mode cartesian/joints
lb_mode1, lb_mode2, lb_mode3, lb_mode4, lb_mode5,