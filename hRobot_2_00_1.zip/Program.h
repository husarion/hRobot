
char program1[] = "SET P0 J; SET P1 C 255 0 50 0 0; SHOWALL;\n";
char program2[] = "\n";
char program3[] = "\n";
char program4[] = "\n";
char program5[] = "\n";
char program6[] = "\n";
char program7[] = "\n";
char program8[] = "\n"; 